import requests
import streamlit as st 
from streamlit_lottie import st_lottie

# trouver plus d'emojis ici: https://www.webfx.com/tools/emoji-cheat-sheet/
st.set_page_config(page_title="hamza taoussi", page_icon=":syringe:", layout="wide")

def load_lottieurl(url):
    r = requests.get(url)
    if r.status_code != 200:
        return None
    return r.json()


# ---load assets---
lottie_coding = load_lottieurl("https://assets3.lottiefiles.com/packages/lf20_tfb3estd.json")
# --- header section --- 
with st.container(): 
    st.subheader("Welcome to my humble site , i am hamza taoussi :wave:")
    st.title("information about me")
    st.write("Je suis programmeur web débutant, j'ai 23 ans, je souffre d'hémophilie chronique, et également responsable des réclamations, à l'Association nationale d’amis et parents d’hémophiles")
    st.write("[ ANAPH ](http://www.anaph.ma)")

    # --- My experiences ----
    with st.container():
        st.write("---")
        left_column, right_column = st.columns(2)
        with left_column:
            st.header("My experiences in life")
            st.write("##")
            st.write(
                """
                - La première expérience que j'ai vécue,
                - c'est que je souffrais et que je souffrais toujours d'hémophilie.
                - Je souffrais beaucoup, et la raison était que j'avais maintenant des besoins spéciaux,
                - Je souffrais beaucoup dans mes études, 
                - et je manquais beaucoup de mes cours dans le département à cause de la maladie
                - Ma deuxième expérience est le bénévolat, même si je n'étais pas une personne sociale,
                - mais en un instant, j'ai ressenti une grande force,
                - j'ai fondé de nombreux groupes Facebook,
                - travaillant sur le terrain, des œuvres caritatives,
                - culturelles et de divertissement également
                - Les noms des complexes sont les suivants : ( DIAMOND FAMYLL , ONE HAND FOREVR ,
                - THE VOLUNTERS , KINGDOM OF Volunteers) . 
                  """
            )
            st.write("[KINGDOM OF VOLUNTEERS >](https://www.youtube.com/watch?v=YEQKgw_eu3Y)")
with right_column:
    st_lottie(lottie_coding, height=600, key="coding")
st.write("[FACEBOOK](https://www.facebook.com/hamzaa.taoussi)")
st.write("[INSTAGRAM](https://www.instagram.com/hamzaa_taoussi/)")